//
//  RelatedHeaderCollectionReusableView.m
//  TaoBaoShoppingCart
//
//  Created by MKJING on 16/9/13.
//  Copyright © 2016年 MKJING. All rights reserved.
//

#import "RelatedHeaderCollectionReusableView.h"

@implementation RelatedHeaderCollectionReusableView

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

@end
