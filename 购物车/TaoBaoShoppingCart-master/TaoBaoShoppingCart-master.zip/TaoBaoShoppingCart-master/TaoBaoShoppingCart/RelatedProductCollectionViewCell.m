//
//  ContryProductCollectionViewCell.m
//  Taowaitao
//
//  Created by 宓珂璟 on 16/6/8.
//  Copyright © 2016年 walatao.com. All rights reserved.
//

#import "RelatedProductCollectionViewCell.h"

@implementation RelatedProductCollectionViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

@end
