//
//  shoppingCartModel.m
//  TaoBaoShoppingCart
//
//  Created by MKJING on 16/9/10.
//  Copyright © 2016年 MKJING. All rights reserved.
//

#import "shoppingCartModel.h"

@implementation BuyerInfo

@end

@implementation ProductInfo

@end

@implementation ModelDeatail

@end

@implementation RelatedProducts

@end

@implementation SingleProduct

@end
