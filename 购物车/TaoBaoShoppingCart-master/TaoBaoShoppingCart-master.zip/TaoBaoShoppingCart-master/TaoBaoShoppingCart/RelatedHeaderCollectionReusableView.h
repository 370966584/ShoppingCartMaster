//
//  RelatedHeaderCollectionReusableView.h
//  TaoBaoShoppingCart
//
//  Created by MKJING on 16/9/13.
//  Copyright © 2016年 MKJING. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RelatedHeaderCollectionReusableView : UICollectionReusableView

@end
