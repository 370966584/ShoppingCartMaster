# TaoBaoShoppingCart
高仿淘宝购物车

1.给UIKit控件增加Badge

2.内嵌凹陷的效果

3.购物车内部计算价格，选择数量，编辑多选删除等功能

4.底部展示相关商品宫格效果

5.试试一个图片展示的组件

:clap:  :clap:  :clap:  :clap:


![Alt Text](https://github.com/DeftMKJ/TaoBaoShoppingCart/blob/master/222.gif)
![Alt Text](https://github.com/DeftMKJ/TaoBaoShoppingCart/blob/master/111.gif)
