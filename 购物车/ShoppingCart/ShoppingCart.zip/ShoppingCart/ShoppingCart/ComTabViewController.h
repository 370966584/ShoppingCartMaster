//
//  ComTabViewController.h
//  INongBao
//
//  Created by lipeng on 16/6/15.
//  Copyright © 2016年 common. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ComTabViewController : UITabBarController 

@end
