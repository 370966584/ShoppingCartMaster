//
//  ComRootNavigationController.h.h
//  CommonApp
//
//  Created by lipeng on 16/3/7.
//  Copyright © 2016年 common. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ComRootNavigationController : UINavigationController

@end
