//
//  UICellButton.m
//  MessageCenter
//
//  Created by apple on 15/8/26.
//  Copyright (c) 2015年 DYC暴君. All rights reserved.
//

#import "UICellButton.h"

@implementation UICellButton
@end
